import { computed } from './computed'

/**
 * @deprecated use `computed` instead. See #5912
 */
export const deferredComputed = computed
